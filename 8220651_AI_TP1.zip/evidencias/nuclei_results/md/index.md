| Hostname/IP | Finding | Severity |
| --- | --- | --- |
| [10.0.10.10](waf-detect-10.0.10.10-e83ce1cd-f6fe-4ea3-8f65-8a742ee0f130-aspgeneric.md) | waf-detect aspgeneric | info |
| [10.0.10.10](waf-detect-10.0.10.10-aa579a45-0116-43bf-bf99-cacdfec6adf3-modsecurity.md) | waf-detect modsecurity | info |
| [10.0.10.12](waf-detect-10.0.10.12-f806633d-57f1-491e-8d65-190d8020577d-apachegeneric.md) | waf-detect apachegeneric | info |
| [10.0.10.12:22](CVE-2023-48795-10.0.10.12_22-4e91e98d-c43c-4c5d-9a70-61c5a937b33d.md) | CVE-2023-48795  | medium |
| [10.0.10.12:22](ssh-auth-methods-10.0.10.12_22-903c4ad3-7c28-49d5-a280-48417dfbc5f8.md) | ssh-auth-methods  | info |
| [10.0.10.10:389](ldap-metadata-10.0.10.10_389-7c402ed1-c4ff-49df-a774-3ecfc0f4a031.md) | ldap-metadata  | info |
| [10.0.10.12:22](ssh-sha1-hmac-algo-10.0.10.12_22-34cb6860-8880-43ed-8610-007b80a4c3a2.md) | ssh-sha1-hmac-algo  | info |
| [10.0.10.12:22](ssh-password-auth-10.0.10.12_22-dd0af00b-256c-404e-98a4-04ea393e5592.md) | ssh-password-auth  | info |
| [10.0.10.10:445](smb2-capabilities-10.0.10.10_445-46c5b8a4-b916-4d99-8941-0fb4389e43ee.md) | smb2-capabilities  | info |
| [10.0.10.10:445](smb2-server-time-10.0.10.10_445-c44a6b8d-e283-4d3f-939e-99e92e7e1516.md) | smb2-server-time  | info |
| [10.0.10.12:22](ssh-server-enumeration-10.0.10.12_22-1cbdf4be-fa77-4030-8fcd-cab51c24feef.md) | ssh-server-enumeration  | info |
| [10.0.10.10:445](smb-enum-10.0.10.10_445-04247c6a-f2be-4424-8e68-4d735ee5c23e.md) | smb-enum  | info |
| [10.0.10.10:445](smb-enum-domains-10.0.10.10_445-5132fcd5-e7b9-445d-89f8-dba6734e85c7.md) | smb-enum-domains  | info |
| [10.0.10.10:445](smb-os-detect-10.0.10.10_445-ffea6855-1674-4398-9e33-5b4ef7119035.md) | smb-os-detect  | info |
| [10.0.10.12:22](openssh-detect-10.0.10.12_22-54d42fc4-f8c3-4e46-ad0a-0561224e98b9.md) | openssh-detect  | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-a1a4268f-ec46-476f-8130-2c7ef9fed164-x-frame-options.md) | http-missing-security-headers x-frame-options | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-e2c1311a-310c-4fb3-a4e1-51ccc0e20e31-x-frame-options.md) | http-missing-security-headers x-frame-options | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-646680c2-ad85-44d9-a1c4-fde09d899b7a-x-content-type-options.md) | http-missing-security-headers x-content-type-options | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-9608e370-9864-4f34-8b1b-f11f8b759fac-x-content-type-options.md) | http-missing-security-headers x-content-type-options | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-aa2e78a3-64e2-4797-867e-d3dfeb4c80f1-referrer-policy.md) | http-missing-security-headers referrer-policy | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-0b2ac4c6-4218-4efb-82cd-0c71003cdc3d-x-permitted-cross-domain-policies.md) | http-missing-security-headers x-permitted-cross-domain-policies | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-4b28afb9-644a-49f5-8f39-42a96ef14d76-clear-site-data.md) | http-missing-security-headers clear-site-data | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-bac79400-babc-49fe-a55e-a2594c41d2f9-referrer-policy.md) | http-missing-security-headers referrer-policy | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-dda5299b-dd77-4282-a318-d6bca428fd3a-cross-origin-resource-policy.md) | http-missing-security-headers cross-origin-resource-policy | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-7ad7f81d-d231-434a-a654-2820976ea63c-cross-origin-embedder-policy.md) | http-missing-security-headers cross-origin-embedder-policy | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-314cbeb1-135d-489c-9fbf-f8ae05c49f8a-strict-transport-security.md) | http-missing-security-headers strict-transport-security | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-8d01506a-e5f6-442b-9616-4aa13ae9718e-cross-origin-opener-policy.md) | http-missing-security-headers cross-origin-opener-policy | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-54e368ac-e933-427a-ab68-0009a36b8e8d-permissions-policy.md) | http-missing-security-headers permissions-policy | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-499282f3-bbaa-4b7b-988b-371e1e8edd77-strict-transport-security.md) | http-missing-security-headers strict-transport-security | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-23ec1872-e70a-4c1a-8321-faefe60fd44f-content-security-policy.md) | http-missing-security-headers content-security-policy | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-9ebace4d-8159-4837-9a9c-ccd61182560e-x-permitted-cross-domain-policies.md) | http-missing-security-headers x-permitted-cross-domain-policies | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-2013c539-98a0-4cb8-89f7-d6b6f50d99b3-cross-origin-embedder-policy.md) | http-missing-security-headers cross-origin-embedder-policy | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-e3f545e6-d25d-4023-a21a-af817c2baa17-cross-origin-resource-policy.md) | http-missing-security-headers cross-origin-resource-policy | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-a1fe906d-31b1-448b-b658-a5a65d16c2c3-cross-origin-opener-policy.md) | http-missing-security-headers cross-origin-opener-policy | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-eed62a83-0713-49cb-927b-8ae0fb4494e0-permissions-policy.md) | http-missing-security-headers permissions-policy | info |
| [10.0.10.10](http-missing-security-headers-10.0.10.10-a606a104-f336-454d-a198-800397ba8e26-content-security-policy.md) | http-missing-security-headers content-security-policy | info |
| [10.0.10.12](http-missing-security-headers-10.0.10.12-ec959b81-5011-4d0b-a734-e3db9fb0241a-clear-site-data.md) | http-missing-security-headers clear-site-data | info |
| [10.0.10.12](options-method-10.0.10.12-73424757-9d16-4e8e-b69a-cc4781576efb.md) | options-method  | info |
| [10.0.10.10](options-method-10.0.10.10-2b52e69c-ccbc-4159-8732-9f1270358452.md) | options-method  | info |
| [10.0.10.10](microsoft-iis-version-10.0.10.10-59113866-bdeb-41f2-b862-099bc8341311.md) | microsoft-iis-version  | info |
| [10.0.10.10](default-windows-server-page-10.0.10.10-e5964f0d-7fda-45ee-aadd-d95989eed99b.md) | default-windows-server-page  | info |
| [10.0.10.12](apache-detect-10.0.10.12-ad341863-23ea-434b-b7d6-460e61438334.md) | apache-detect  | info |
| [10.0.10.12](default-apache-test-all-10.0.10.12-d66f7a84-ce33-4598-9df9-a34a61cffe88.md) | default-apache-test-all  | info |
| [10.0.10.12](default-apache2-ubuntu-page-10.0.10.12-ae0822fc-ffe4-446a-a878-1eea65a46a4e.md) | default-apache2-ubuntu-page  | info |
| [10.0.10.10](tech-detect-10.0.10.10-241f72b7-8bee-4fe2-b9e7-a944fee61981-ms-iis.md) | tech-detect ms-iis | info |
