### Apache Server Status Disclosure (apache-server-status) found on zero.webappsecurity.com

----
**Details**: **apache-server-status** matched at zero.webappsecurity.com

**Protocol**: HTTP

**Full URL**: http://zero.webappsecurity.com/server-status

**Timestamp**: Mon May 19 19:11:39 +0100 WEST 2025

**Template Information**

| Key | Value |
| --- | --- |
| Name | Apache Server Status Disclosure |
| Authors | thabisocn |
| Tags | misconfig, exposure, apache, debug |
| Severity | low |
| Description | Apache /server-status displays information about your Apache status. If you are not using this feature, disable it.<br> |

**Request**
```http
GET /server-status HTTP/1.1
Host: zero.webappsecurity.com
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip


```

**Response**
```http
HTTP/1.1 200 OK
Connection: close
Content-Length: 5523
Access-Control-Allow-Origin: *
Content-Type: text/html;charset=UTF-8
Date: Mon, 19 May 2025 18:27:30 GMT
Server: Apache-Coyote/1.1

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html><head>
    <title>Apache Status</title>
</head><body>
<h1>Apache Server Status for localhost</h1>

<dl><dt>Server Version: Apache/2.2.22 (Win32) mod_ssl/2.2.22 OpenSSL/0.9.8t mod_jk/1.2.37</dt>
    <dt>Server Built: Jan 28 2012 11:16:39
    </dt></dl><hr /><dl>
    <dt>Current Time: Friday, 18-Jan-2013 14:55:36 GMT</dt>
    <dt>Restart Time: Friday, 18-Jan-2013 14:29:04 GMT</dt>
    <dt>Parent Server Generation: 0</dt>
    <dt>Server uptime:  26 minutes 31 seconds</dt>
    <dt>5 requests currently being processed, 59 idle workers</dt>
</dl><pre>_________________________________________________K_____KK_W__K__
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
................................................................
</pre>
<p>Scoreboard Key:<br />
    "<b><code>_</code></b>" Waiting for Connection,
    "<b><code>S</code></b>" Starting up,
    "<b><code>R</code></b>" Reading Request,<br />
    "<b><code>W</code></b>" Sending Reply,
    "<b><code>K</code></b>" Keepalive (read),
    "<b><code>D</code></b>" DNS Lookup,<br />
    "<b><code>C</code></b>" Closing connection,
    "<b><code>L</code></b>" Logging,
    "<b><code>G</code></b>" Gracefully finishing,<br />
    "<b><code>I</code></b>" Idle cleanup of worker,
    "<b><code>.</code></b>" Open slot with no current process</p>
<p />
PID Key: <br />
<pre>
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: K ,   11740 in state: _
   11740 in state: _ ,   11740 in state: _ ,   11740 in state: _
   11740 in state: _ ,   11740 in state: K ,   11740 in state: K
   11740 in state: _ ,   11740 in state: W ,   11740 in state: _
   11740 in state: _ ,   11740 in state: K ,   11740 in state: _
   11740 in state: _ ,
</pre>
<hr />To obtain a full report with current status information you need to use the <code>ExtendedStatus On</code> directive.
<hr>
<table cellspacing=0 cellpadding=0>
    <tr><td bgcolor="#000000">
        <b><font color="#ffffff" face="Arial,Helvetica">SSL/TLS Session Cache Status:<.... Truncated ....
```

References: 
- https://www.exploit-db.com/ghdb/5548
- https://www.invicti.com/web-vulnerability-scanner/vulnerabilities/apache-server-status-detected/
- https://www.acunetix.com/vulnerabilities/web/apache-server-status-detected/

**CURL command**
```sh
curl -X 'GET' -H 'Accept: */*' -H 'Accept-Language: en' -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1' 'http://zero.webappsecurity.com/server-status'
```

----

Generated by [Nuclei v3.4.4](https://github.com/projectdiscovery/nuclei)