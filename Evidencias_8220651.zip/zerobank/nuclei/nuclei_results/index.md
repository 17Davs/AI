| Hostname/IP | Finding | Severity |
| --- | --- | --- |
| [zero.webappsecurity.com](waf-detect-zero.webappsecurity.com-d938f2a7-50a0-4dda-872c-251af7f78d2a-apachegeneric.md) | waf-detect apachegeneric | info |
| [zero.webappsecurity.com](old-copyright-zero.webappsecurity.com-e0938d8e-55ba-44b3-84b3-012062907ea9.md) | old-copyright  | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-d9805a4c-5f5d-4a2c-b8b9-82d422884009-cross-origin-opener-policy.md) | http-missing-security-headers cross-origin-opener-policy | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-2f159b8a-a39e-43f4-b212-75732d2af801-content-security-policy.md) | http-missing-security-headers content-security-policy | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-9177f575-7e60-4e45-afc2-0ec8ee1d4ad9-x-frame-options.md) | http-missing-security-headers x-frame-options | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-4635cc82-e25f-4ca8-9564-7a27f1cd5caf-x-content-type-options.md) | http-missing-security-headers x-content-type-options | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-48ceb1c4-8ac7-44b2-8dca-0b9ec48222a2-clear-site-data.md) | http-missing-security-headers clear-site-data | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-3e8f5e25-86db-43fb-befc-dacd5bfb0b0d-cross-origin-embedder-policy.md) | http-missing-security-headers cross-origin-embedder-policy | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-f2540275-8432-4ac8-8ba2-1a951cfe0565-cross-origin-resource-policy.md) | http-missing-security-headers cross-origin-resource-policy | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-7c1d9974-61ea-4ff2-92ef-312662ca71d6-strict-transport-security.md) | http-missing-security-headers strict-transport-security | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-5c021cd4-ac9e-4ff0-9374-e4f1bb2046c7-permissions-policy.md) | http-missing-security-headers permissions-policy | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-5b21ecae-df54-4f20-8087-182a5193c544-x-permitted-cross-domain-policies.md) | http-missing-security-headers x-permitted-cross-domain-policies | info |
| [zero.webappsecurity.com](http-missing-security-headers-zero.webappsecurity.com-fa737d5a-f74f-4c63-b568-91ae100564e1-referrer-policy.md) | http-missing-security-headers referrer-policy | info |
| [zero.webappsecurity.com](tomcat-exposed-zero.webappsecurity.com-81157f8e-051a-4a06-ad8f-3f455ef559da.md) | tomcat-exposed  | info |
| [zero.webappsecurity.com](options-method-zero.webappsecurity.com-6cd27c74-b27c-4c0e-a197-cbb4329712e7.md) | options-method  | info |
| [zero.webappsecurity.com](tomcat-manager-pathnormalization-zero.webappsecurity.com-a91960df-8b21-4c92-8d1e-c9bffc5d3f2a.md) | tomcat-manager-pathnormalization  | info |
| [zero.webappsecurity.com](apache-server-status-zero.webappsecurity.com-e0b4a05e-5fdf-4c8f-808e-c5234758760b.md) | apache-server-status  | low |
| [zero.webappsecurity.com](apache-detect-zero.webappsecurity.com-1e3a0e5c-6c60-4c3d-bd46-cf00302c7a42.md) | apache-detect  | info |
| [zero.webappsecurity.com](tomcat-detect-zero.webappsecurity.com-ab981c09-dce9-4ef0-8dc5-124448dbeeb6-.md) | tomcat-detect  | info |
| [zero.webappsecurity.com](public-tomcat-manager-zero.webappsecurity.com-a37240d5-8124-48db-b5fa-d8842f5ac52d.md) | public-tomcat-manager  | info |
| [zero.webappsecurity.com](tech-detect-zero.webappsecurity.com-22a96e70-8b07-410e-bc36-843018e7c026-font-awesome.md) | tech-detect font-awesome | info |
| [zero.webappsecurity.com](tech-detect-zero.webappsecurity.com-cf0a7363-02fd-42d5-8617-9e4524a80fda-bootstrap.md) | tech-detect bootstrap | info |
| [zero.webappsecurity.com](form-detection-zero.webappsecurity.com-c08751a0-8a84-470b-8248-55b142be9e44.md) | form-detection  | info |
| [zero.webappsecurity.com](caa-fingerprint-zero.webappsecurity.com-fc43f998-ba25-4fac-87cb-edf404779207.md) | caa-fingerprint  | info |
