### HTTP Missing Security Headers (http-missing-security-headers:content-security-policy) found on zero.webappsecurity.com

----
**Details**: **http-missing-security-headers:content-security-policy** matched at zero.webappsecurity.com

**Protocol**: HTTP

**Full URL**: http://zero.webappsecurity.com

**Timestamp**: Mon May 19 19:11:23 +0100 WEST 2025

**Template Information**

| Key | Value |
| --- | --- |
| Name | HTTP Missing Security Headers |
| Authors | socketz, geeknik, g4l1t0, convisoappsec, kurohost, dawid-czarnecki, forgedhallpass, jub0bs, userdehghani |
| Tags | misconfig, headers, generic |
| Severity | info |
| Description | This template searches for missing HTTP security headers. The impact of these missing headers can vary.<br> |

**Request**
```http
GET / HTTP/1.1
Host: zero.webappsecurity.com
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.7.19
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip


```

**Response**
```http
HTTP/1.1 200 OK
Connection: close
Transfer-Encoding: chunked
Access-Control-Allow-Origin: *
Cache-Control: no-cache, max-age=0, must-revalidate, no-store
Content-Language: en
Content-Type: text/html;charset=UTF-8
Date: Mon, 19 May 2025 18:27:15 GMT
Server: Apache-Coyote/1.1


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Zero - Personal Banking - Loans - Credit Cards</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">

    <link type="text/css" rel="stylesheet" href="/resources/css/bootstrap.min.css"/>
    <link type="text/css" rel="stylesheet" href="/resources/css/font-awesome.css"/>
    <link type="text/css" rel="stylesheet" href="/resources/css/main.css"/>

    <script src="/resources/js/jquery-1.8.2.min.js"></script>
        <script src="/resources/js/bootstrap.min.js"></script>

    <script src="/resources/js/placeholders.min.js"></script>
    <script type="text/javascript">
        Placeholders.init({
            live: true, // Apply to future and modified elements too
            hideOnFocus: true // Hide the placeholder when the element receives focus
        });
    </script>
    <script type="text/javascript">
        $(document).ajaxError(function errorHandler(event, xhr, ajaxOptions, thrownError) {
            if (xhr.status == 403) {
                window.location.reload();
            }
        });
    </script>
</head>
<body>
    <div class="wrapper">
    <div class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a href="/index.html" class="brand">Zero Bank</a>

                <div>
                    <ul class="nav float-right">
                        <li>    <form action="/search.html"
          class="navbar-search pull-right" style="padding-right: 20px">
        <input type="text" id="searchTerm" name="searchTerm" class="search-query" placeholder="Search"/>
    </form>
</li>
                        <li>
                            <button id="signin_button" type="button" class="signin btn btn-info">
                                <i class="icon-signin"></i>Signin
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(function() {
            var path = "/";

            $("#signin_button").click(function(event) {
                event.preventDefault();
                window.location.href = path + "login" + ".html";
            });
        });
    </script>

        <div class="container">
            <div class="top_offset">
                    <div class="row">
    <div class="span12">
        <div id="nav" class="clearfix">
            <ul id="pages-nav">
                <li id="homeMenu"><div><strong>Home</strong></div></li>
                <li id="onlineBankingMenu"><div><strong>Online Banking</strong></div></li>
                <li id="feedback"><div><strong>Feedback</strong></div></li>
            </ul>
        </div>
    </div>

    <script type="text/javascript">
        $(function () {
            var path = "/";

            var featureIdToName = {
                "index": "homeMenu",
                "online-banking": "onlineBankingMenu",
                "feedback": "feedback"
            };

            if (document.location.href.match(".*" + path + "$") != null) {
                $("#homeMenu").addClass("active");
            } else {
                $.each(featureIdToName, function(featureId, featureName) {
                    if (document.location.href.indexOf(featureId + ".html") >= 0) {
                        $("#" + featureName).addClass("active");
                    }
                });
            }

            $.each(featureIdToName, function(featureId, featureName) {
                $("#nav").on("click", "li[id='" + featureName + "']", function(event) {
                    event.preventDefault();
                    window.location.href = path + featureId + ".html";
                });
            });
        });
    </script>
                    </div>

<div class="row">
    <div class="span12">
        <div id="carousel" class="carousel slide">
            <div class="carousel-inner">
                <div class="active item">
                    <img src="/resources/img/main_carousel_1.jpg" width="940" height="401" alt=""/>
                    <div class="custom carousel-caption">
                        <h4>Online Banking</h4>
                        <p>Welcome to Zero Online Banking. Zero provides a greener and more convenient way to manage your money. Zero enables you to check your account balances, pay your bills, transfer money, and  keep detailed records of your transactions,  wherever there is an internet connection.</p>
                    </div>
                </di.... Truncated ....
```


**CURL command**
```sh
curl -X 'GET' -H 'Accept: */*' -H 'Accept-Language: en' -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.7.19' 'http://zero.webappsecurity.com'
```

----

Generated by [Nuclei v3.4.4](https://github.com/projectdiscovery/nuclei)